int lampu=26;
int lampu2=27;
int tombol=26;
int tombol2=27;

void setup() {
  // put your setup code here, to run once:
  Serial.begin(115200);
  Serial.println("Hello, ESP32!");
  pinMode(lampu, OUTPUT);
  pinMode(lampu2, OUTPUT);
  pinMode(tombol, OUTPUT);
  pinMode(tombol, OUTPUT);
}

void loop() {
  digitalWrite(lampu, HIGH);
  digitalWrite(lampu2, HIGH);
  digitalWrite(tombol, HIGH);
  digitalWrite(tombol2, HIGH);

  
  // put your main code here, to run repeatedly:
  delay(1000); // this speeds up the simulation
  digitalWrite(lampu, LOW);
  digitalWrite(lampu2, LOW);
  digitalWrite(tombol, LOW);
  digitalWrite(tombol2, LOW);
}
